import tkinter as tk
import pandas as pd
import os
import pyautogui as py
import ProcesoTP1 as TP1
import Cajas as CJ
import openpyxl
import sqlite3
import difflib
from openpyxl.cell.cell import ILLEGAL_CHARACTERS_RE
from tkinter import PhotoImage
from datetime import datetime

#Variable global para almacenar la carpeta de resultados
carpeta_salida_global = None

#==============================================================================
#Crear carpeta de resultados con timestamp
#==============================================================================
def crear_carpeta_resultados():
    global carpeta_salida_global
    if carpeta_salida_global is None:
        ruta_base = os.getcwd()
        timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        carpeta_botbanco = os.path.join(ruta_base, f"BOT_BANCO_{timestamp}")
        
        if not os.path.exists(carpeta_botbanco):
            os.makedirs(carpeta_botbanco)
        
        carpeta_salida_global = carpeta_botbanco
    
    return carpeta_salida_global

#==============================================================================
#Parametros de Iniciio
#Funcion que obtiene datos de parametros de inicio
#==============================================================================
def ParametrosInicio():
    global varInicial
    varInicial =[['Ruta del Aplicativo'],['']]
    varInicial[1][0]=os.getcwd() #Ruta del aplicativo
    path_varini=varInicial[1][0]+ '\\VariablesInicio.txt'  #r'.\usuario.txt' #Archivo de tipo txt donde se encuentra el nombre de usuario intranet
    abspath_usuario=os.path.abspath(path_varini)#Ruta del archivo txt   
    with open (abspath_usuario) as Usuario: # Variables Iniciales   
        for a,line in enumerate(Usuario):  #Leyedo usuario intranet
            valoresAux= line[0:len(line)-1].split('|')
            varInicial[0].append(valoresAux[0]) #Ingreso de nombre
            varInicial[1].append(valoresAux[1]) #Ingreso de valor
    
#==============================================================================
#================================================================================
# Procedimiento para :
# 
#==============================================================================   
def leerBaseDatos(arch, skiprows=0):
    baseData=[]
    rutaOrig=varInicial[1][0]
    rutaOrig=rutaOrig + '\Base_Datos'
    #archivosT01=os.listdir(rutaOrig)
    #print(archivosT01)
    #for arch in archivosT01:
    if arch[len(arch)-5:].lower()=='.xlsx':
        excel_of=pd.ExcelFile(rutaOrig +'\\' + arch) #Lee archivo excel
        hojaB=excel_of.parse(0,skiprows=skiprows,dtype =str)
        hojaB.fillna("", inplace = True)
        baseData.append([rutaOrig +'\\' + arch,arch,hojaB ])
        excel_of.close()
    elif arch[len(arch)-4:].lower()=='.txt':
        df = pd.read_csv(rutaOrig +'\\' + arch, sep="|",encoding='latin-1',keep_default_na=False
                         ,dtype =str)
        baseData.append([rutaOrig +'\\' + arch,arch,df])
    return  baseData
#==============================================================================
#================================================================================
# Procedimiento para :
# 
#==============================================================================   
def leerBaseDatos_1():
    baseData=[]
    rutaOrig=varInicial[1][0]
    rutaOrig=rutaOrig + '\Base_Datos'
    archivosT01=os.listdir(rutaOrig)
    #print(archivosT01)
    for arch in archivosT01:
        if arch[len(arch)-5:].lower()=='.xlsx':
            excel_of=pd.ExcelFile(rutaOrig +'\\' + arch) #Lee archivo excel
            hojaB=excel_of.parse(0,dtype =str)
            hojaB.fillna("", inplace = True)
            baseData.append([rutaOrig +'\\' + arch,arch,hojaB ])
            excel_of.close()
        elif arch[len(arch)-4:].lower()=='.txt':
            df = pd.read_csv(rutaOrig +'\\' + arch, sep="|",encoding='latin-1',keep_default_na=False
                             ,dtype =str)
            baseData.append([rutaOrig +'\\' + arch,arch,df])
    return  baseData
#==============================================================================
#==============================================================================
def PBusquedaP(areaR1):
    carpeta_salida = crear_carpeta_resultados()
    nombreBL='Base_Busqueda.xlsx'
    nombreHB='Base'
    nombreCBD='Base_Busqueda'
    nombreR="_R"
    areaR=areaR1
    skiprows_applied=0
    if areaR!=0:
        resultadosB=LeerResultados(nombreBL,nombreHB)
        if areaR==1:
            basetB=leerBaseDatos('1_BANCOS_VEND_INMUEB_CREDHIP_2025.xlsx', skiprows=1)
            skiprows_applied=1
            BusquedaBProc(basetB,resultadosB,['ape_pat','ape_mat','nombre','razon',''],skiprows_applied)
            BusquedaBRUC(basetB,resultadosB,'RUC_INFORMADO',skiprows_applied)
            nombreR="_R_BANCOS_VEND_INMUEB_CREDHIP_2025"
        elif areaR==2:
            # Usar la lógica de Cajas.py para búsqueda en base de datos SQLite
            PBusquedaCajas(resultadosB, carpeta_salida)
            return  # Salir sin procesar el guardado tradicional
        elif areaR==3:
            basetB=leerBaseDatos('3_TBL_MUNI_PREDIOS_2025.txt')
            BusquedaBProc2(basetB,resultadosB,['nombre'],skiprows_applied)
            BusquedaBRUC(basetB,resultadosB,'RUC_INFORMADO',skiprows_applied)
            nombreR="_R_TBL_MUNI_PREDIOS_2025"
        try: 
            excel_document_c = openpyxl.load_workbook(varInicial [1][0] + '\\' + nombreBL)
            sheetc = excel_document_c[nombreHB]#excel_document_c.get_sheet_by_name(nombreHB)
            j=2
            for i in resultadosB.index: 
                print("Guardar-->" + str(i))
                sheetc.cell(j, 6).value=resultadosB['Porcentaje'][i]
                print(len(resultadosB['Libro'][i]))
                if len(str(resultadosB['Libro'][i]))<= 320000:
                    sheetc.cell(j, 7).value=resultadosB['Libro'][i]
                else:
                    sheetc.cell(j, 7).value=str(resultadosB['Libro'][i])[0:320000]
                print(len(str(resultadosB['Hoja'][i]))<= 32000)
                if len(str(resultadosB['Hoja'][i]))<= 320000:
                    sheetc.cell(j, 8).value=resultadosB['Hoja'][i]
                else:
                    sheetc.cell(j, 8).value=str(resultadosB['Hoja'][i])[0:320000]
                if len(str(resultadosB['Fila'][i]))<= 320000:
                    sheetc.cell(j, 9).value=resultadosB['Fila'][i]
                else:
                    sheetc.cell(j, 9).value=str(resultadosB['Fila'][i])[0:320000]
                if len(str(resultadosB['Columna'][i]))<= 320000:
                    sheetc.cell(j, 10).value=resultadosB['Columna'][i]
                else:
                    sheetc.cell(j, 10).value=str(resultadosB['Columna'][i])[0:320000]
                    
                auxValorR=resultadosB['Valor'][i]
                if len(auxValorR)> 320000 :
                    auxValorR=auxValorR[0:320000]
                    
                auxValorR=ILLEGAL_CHARACTERS_RE.sub(r'',auxValorR)
                sheetc.cell(j, 11).value=str(auxValorR).encode("ascii",errors="ignore")
                j+=1
            archivo_resultado = os.path.join(carpeta_salida, nombreBL[0:len(nombreBL)-5] + nombreR + '.xlsx')
            excel_document_c.save(archivo_resultado)
            excel_document_c.close()
        except Exception as e:
            print("Se produjo un error")
            print(e)
            archivo_resultado = os.path.join(carpeta_salida, nombreBL[0:len(nombreBL)-5] + nombreR + '.xlsx')
            excel_document_c.save(archivo_resultado)
            excel_document_c.close()
#==============================================================================
#
#
#==============================================================================
def BusquedaBProc(basetB,resultadosB,Ffinal,skiprows_applied=0):
    try: 
        for fbasetB in basetB:
            # Usar iloc para evitar advertencias de pandas
            fbasetB[2] = fbasetB[2].fillna("")
        nombreP =[["","",""],[0]]
        for fbasetB in basetB:
            print('Proceso_BusquedaBProc_P_1_0')
            for b,nBuscar in enumerate(resultadosB['NOMBRE_BUSQUEDA']):
                try:
                    nBuscar=nBuscar.strip()
                    # Solo procesar si NOMBRE_BUSQUEDA tiene contenido
                    if len(nBuscar)>0:
                            # Convertir RUC a string para evitar errores de tipo
                            ruc_str = str(resultadosB['RUC'][b]).strip()
                            if len(ruc_str)==11 and ruc_str[0:1]=='2':
                                nombreP[0][0]=nBuscar
                                idB=1
                                colB1=Ffinal[3]
                                colB2=''
                                colB3=''
                                a=6
                            else:
                               nombreP[0]=nBuscar.split('|')
                               # Validar que tenemos al menos 3 elementos después del split
                               if len(nombreP[0]) < 3:
                                   # Rellenar con cadenas vacías si faltan elementos
                                   while len(nombreP[0]) < 3:
                                       nombreP[0].append('')
                               idB=0
                               a=4
                               colB1=Ffinal[0]
                               colB2=Ffinal[1]
                               colB3=Ffinal[2]
                            apellidoC=nombreP[0][0] #+ ' ' + nombreP[0][1]
                            nombreC=nombreP[0][2].split(' ') if nombreP[0][2] else ['']
                            nombreCC= apellidoC +' ' + nombreP[0][2]
                            longitudN=len(nombreP[0][2])
                            longitudAp=len(apellidoC)
                            print('Proceso_BusquedaBProc_P_1_1' + '-->'+str(b))
                            valoresAux= fbasetB[2][fbasetB[2][colB1].str.contains(apellidoC,case=False)]#,regex=False)] # 
                            print(fbasetB[0],fbasetB[1],apellidoC,b,len(valoresAux))
                            if len(valoresAux)>0: 
                                print('Proceso_BusquedaBProc_P_1_1_1' + '-->'+colB1 + '--'+str(b))
                                if idB==0:
                                    print('Proceso_BusquedaBProc_P_1_1_2' + '-->')
                                    valoresV=valoresAux
                                    valoresAux1= valoresAux[valoresAux[colB2].str.contains(nombreP[0][1],case=False)]#,regex=False)]
                                    auxP=0
                                    if len(valoresAux1)>0:
                                        print('Proceso_BusquedaBProc_P_1_1_3' + '-->')
                                        valoresV=valoresAux1
                                        auxP=40
                                        valoresAux2= valoresAux1[valoresAux1[colB3].str.contains(nombreP[0][2],case=False)]#,regex=False)]
                                        if len(valoresAux2)>0:
                                            print('Proceso_BusquedaBProc_P_1_1_4' + '-->')
                                            valoresV=valoresAux2
                                            auxP=60
                                            for filB, apP,apM,nombC in zip(valoresAux2.index,valoresAux2[colB1],
                                                                           valoresAux2[colB2],valoresAux2[colB3]):
                                                if apP.upper()==nombreP[0][0].upper() and apM.upper()==nombreP[0][1].upper() and nombC.upper()==nombreP[0][2].upper():
                                                    auxP=100
                                                    LlenarResultados1(auxP,resultadosB,b,fbasetB[1],filB,colB1,
                                                                      valoresV, a,idB,colB2,colB3,Ffinal[4],skiprows_applied)
                                                    break
                                            LlenarResultados1(auxP,resultadosB,b,fbasetB[1],filB,colB1,
                                                              valoresV, a,idB,colB2,colB3,Ffinal[4],skiprows_applied)
                                        else:
                                            LlenarResultados1(auxP,resultadosB,b,fbasetB[1],valoresV.index[0],colB1,
                                                  valoresV, a,idB,colB2,colB3,Ffinal[4],skiprows_applied)
                                        
                                else:
                                    print('Proceso_BusquedaBProc_P_1_1_2' + '-->')
                                    valoresV=valoresAux
                                    auxP=60
                                    for filB, apP in zip(valoresAux.index,valoresAux[colB1]):
                                        if apP.upper()==nombreP[0][0].upper():
                                            auxP=100
                                            LlenarResultados1(auxP,resultadosB,b,fbasetB[1],filB,colB1,
                                                  valoresV, a,idB,colB2,colB3,Ffinal[4],skiprows_applied)
                                
                                          
                            else:
                                auxP=0
                                if resultadosB['Porcentaje'][b]=="":
                                    resultadosB.loc[b, 'Porcentaje']=str(auxP)
                    else:
                        # Fila vacía, continuar con la siguiente
                        print(f'Fila {b} vacía, saltando...')
                        continue
                except Exception as e:
                    print(f'Error en fila {b}: {str(e)}')
                    # Continuar sin parar la búsqueda
                    continue
    except Exception as e:
        print('Se genero un error -->')
        print(e)
#==============================================================================
#==============================================================================
#
#
#==============================================================================
def BusquedaBProc2(basetB,resultadosB,Ffinal,skiprows_applied=0):
    try: 
        for fbasetB in basetB:
            # Usar fillna sin inplace para evitar advertencias de pandas
            fbasetB[2] = fbasetB[2].fillna("")
        nombreP =[["","",""],[0]]
        for fbasetB in basetB:
            print('Proceso_BusquedaBProc_P_1_0')
            for b,nBuscar in enumerate(resultadosB['NOMBRE_BUSQUEDA']):
                try:
                    nBuscar=nBuscar.strip()
                    # Solo procesar si NOMBRE_BUSQUEDA tiene contenido
                    if len(nBuscar)>0:
                        # Convertir RUC a string para evitar errores de tipo
                        ruc_str = str(resultadosB['RUC'][b]).strip()
                        if len(ruc_str)==11 and ruc_str[0:1]=='2':
                            nombreP[0][0]=nBuscar
                            idB=1
                            colB1=Ffinal[0]
                            a=6
                        else:
                           nombreP[0]=nBuscar.split('|')
                           # Validar que tenemos al menos 3 elementos después del split
                           if len(nombreP[0]) < 3:
                               # Rellenar con cadenas vacías si faltan elementos
                               while len(nombreP[0]) < 3:
                                   nombreP[0].append('')
                           idB=0
                           a=4
                           colB1=Ffinal[0]
                           
                        apellidoC=nombreP[0][0] + ' ' + nombreP[0][1] if nombreP[0][1] else nombreP[0][0]
                        nombreC=nombreP[0][2].split(' ') if nombreP[0][2] else ['']
                        nombreCC= apellidoC +' ' + nombreP[0][2]
                        longitudN=len(nombreP[0][2])
                        longitudAp=len(apellidoC)
                        print('Proceso_BusquedaBProc_P_1_1' + '-->'+str(b))
                        valoresAux= fbasetB[2][fbasetB[2][colB1].str.contains(apellidoC,case=False)] # 
                        print(fbasetB[0],fbasetB[1],apellidoC,b,len(valoresAux))
                        if len(valoresAux)>0: 
                            print('Proceso_BusquedaBProc_P_1_1_1' + '-->'+colB1 + '--'+str(b))
                            if idB==0:
                                print('Proceso_BusquedaBProc_P_1_1_1' + '_'+str(a))
                                apellidoC1=apellidoC.upper()
                                nombreC1=nombreP[0][2].upper()
                                for a1,nrevisar in zip(valoresAux.index,valoresAux[colB1]):
                                    print('Proceso_BusquedaBProc_P_1_1_2' + '_'+str(a1))
                                    auxP=50
                                    nrevisar.upper()
                                    posap=nrevisar.find(apellidoC1)
                                    posnc=nrevisar.find(nombreC1)
                                    if posnc>=0:
                                        print('Proceso_BusquedaBProc_P_1_1_3' + '_'+str(a1))
                                        if posnc<posap:
                                            if posap-posnc-longitudN<=3:
                                                auxP=100
                                
                                            else:
                                                auxP=95
                                        elif posnc>posap:
                                            if posnc-posap-longitudAp<=3:
                                                auxP=100
                                            else:
                                                auxP=95
                                    else:
                                        print('Proceso_BusquedaBProc_P_1_1_4' + '_'+str(a1))
                                        for nauxiN in  nombreC:
                                            nauxiN.upper()
                                            posnc=nrevisar.find(nombreC1)
                                            if posnc>=0:
                                                if posnc<posap:
                                                     if posap-posnc-longitudN<=3:
                                                         auxP=90
                                                         break
                                                     else:
                                                         auxP=60
                                                elif posnc>posap:
                                                     if posnc-posap-longitudAp<=3:
                                                         auxP=90
                                                         break
                                                     else:
                                                         auxP=60
                                    
                                    LlenarResultados(auxP, resultadosB,b,fbasetB[1],a1,colB1,
                                                     valoresAux, a,skiprows_applied)
                                    
                            else:
                                valoresV=valoresAux
                                auxP=60
                                for filB, apP in zip(valoresAux.index,valoresAux[colB1]):
                                    if apP.upper()==nombreP[0][0].upper():
                                        auxP=100
                                        break
                                
                                LlenarResultados(auxP, resultadosB,b,fbasetB[1],filB,
                                                 colB1,valoresV, a,skiprows_applied)
                        else:
                            auxP=0
                            if resultadosB['Porcentaje'][b]=="":
                                resultadosB.loc[b, 'Porcentaje']=str(auxP)
                    else:
                        # NOMBRE_BUSQUEDA está vacío, saltar esta fila
                        print(f'Fila {b}: NOMBRE_BUSQUEDA vacío, saltando...')
                        continue
                except Exception as e:
                    print(f'Error en fila {b}: {str(e)}')
                    # Continuar sin parar la búsqueda
                    continue
    except Exception as e:
        print('Se genero un error -->')
        print(e)
#==============================================================================
#==============================================================================
#
#
#==============================================================================
def BusquedaBRUC(basetB,resultadosB,colRUC,skiprows_applied=0):
    try: 
        for fbasetB in basetB:
            # Usar fillna sin inplace para evitar advertencias de pandas
            fbasetB[2] = fbasetB[2].fillna("")
        nombreP =[["","",""],[0]]
        for fbasetB in basetB:
            print('BusquedaBRUC_P_1_0')
            for b,nBuscar in enumerate(resultadosB['RUC']):
                try:
                    # Convertir nBuscar a string para evitar errores de tipo
                    nBuscar = str(nBuscar).strip()
                    # Solo procesar si RUC tiene contenido
                    if len(nBuscar)>0:
                        # Convertir RUC a string para evitar errores de tipo
                        ruc_str = str(resultadosB['RUC'][b]).strip()
                        if len(ruc_str)==11 and ruc_str[0:1]=='2':
                            nombreP[0][0]=nBuscar
                            idB=1
                            colB1=colRUC
                            a=1
                        else:
                            nombreP[0]=nBuscar.split('|')
                            idB=0
                            a=1
                            colB1=colRUC
                        apellidoC=nombreP[0][0]  #+ ' ' + nombreP[0][1]
                        if apellidoC!='SN' and apellidoC!='-':
                            print('PBusquedaBRUC_P_1_1' + '-->'+str(b))
                            valoresAux= fbasetB[2][fbasetB[2][colB1].str.contains(apellidoC,case=False)] # 
                            print(fbasetB[0],fbasetB[1],apellidoC,b,len(valoresAux))
                            if len(valoresAux)>0: 
                                print('BusquedaBRUC_P_1_1_1' + '-->'+colB1 + '--'+str(b))
                                if idB==0:
                                    valoresV=valoresAux
                                    auxP=60
                                    for a1,nrevisar in zip(valoresAux.index,valoresAux[colB1]):
                                        print('BusquedaBRUC_P_1_1_2' + '_'+str(a1))
                                        filaE=a1
                                        if nrevisar.upper()==apellidoC.upper():
                                            auxP=100
                                            LlenarResultados(auxP, resultadosB,b,fbasetB[1],
                                                 filaE,colB1,valoresV, a,skiprows_applied)
                                        
                                else:
                                    valoresV=valoresAux
                                    auxP=100
                                    filaE=valoresV.index[0]
                                    LlenarResultados(auxP, resultadosB,b,fbasetB[1],
                                                 filaE,colB1,valoresV,a,skiprows_applied)
                                    
                                
                    else:
                        # RUC está vacío, saltar esta fila
                        print(f'Fila {b}: RUC vacío, saltando...')
                        auxP=0
                        if resultadosB['Porcentaje'][b]=="":
                            resultadosB.loc[b, 'Porcentaje']=str(auxP)
                except Exception as e:
                    print(f'Error en fila {b} (RUC): {str(e)}')
                    # Continuar sin parar la búsqueda
                    continue
    except Exception as e:
        print('Se genero un error -->')
        print(e)
#==============================================================================
#==============================================================================
# Función para eliminar Base de Datos de Cajas
#==============================================================================
def EliminarBaseDatos():
    """
    Elimina la base de datos Base_Datos_Proceso.db
    """
    try:
        ruta_base = varInicial[1][0]
        base_p = ruta_base + r"\Base_Datos\Base_Datos_Proceso.db"
        
        if os.path.exists(base_p):
            # Intentar eliminar el archivo
            try:
                os.remove(base_p)
                py.alert("Base de datos eliminada exitosamente.\nPuede cargar nuevos datos.", timeout=1600)
                print(f"Archivo eliminado: {base_p}")
            except PermissionError:
                py.alert("ERROR: No se puede eliminar el archivo.\nVerifique que no esté en uso.", timeout=1600)
                print("Permiso denegado al intentar eliminar el archivo")
            except Exception as e:
                py.alert(f"ERROR al eliminar la base de datos:\n{str(e)}", timeout=1600)
                print(f"Error: {str(e)}")
        else:
            py.alert("La base de datos no existe.", timeout=1600)
            print(f"Archivo no encontrado: {base_p}")
    except Exception as e:
        print(f"Error en EliminarBaseDatos: {str(e)}")
        py.alert(f"Error al eliminar base de datos:\n{str(e)}")

#==============================================================================
#==============================================================================
# Búsqueda en bases de datos SQLite de Cajas
#==============================================================================
def PBusquedaCajas(resultadosB, carpeta_salida):
    """
    Realiza búsqueda en base de datos SQLite de Cajas.
    Verifica si los datos están cargados y los carga si es necesario.
    """
    try:
        # Rutas de archivos
        ruta_base = varInicial[1][0]
        archivo_202501_202506 = ruta_base + r"\Base_Datos\2_CAJAS_CREDDESEMBOLSADOS_202501_202506.txt"
        archivo_202507_202512 = ruta_base + r"\Base_Datos\2_CAJAS_CREDDESEMBOLSADOS_202507_202512.txt"
        base_p = ruta_base + r"\Base_Datos\Base_Datos_Proceso.db"
        nombre_tabla = "BANCOS_CAJAS_CREDDESEMBOLSADOS"
        
        # Verificar si existen los archivos TXT
        archivo_1_existe = os.path.exists(archivo_202501_202506)
        archivo_2_existe = os.path.exists(archivo_202507_202512)
        
        if not archivo_1_existe and not archivo_2_existe:
            py.alert("ERROR: No se encontraron los archivos de datos de Cajas\nEsperados:\n" +
                    archivo_202501_202506 + "\n" + archivo_202507_202512)
            return
        
        # Obtener períodos ya cargados
        periodos_cargados = CJ.ObtenerPeriodosDisponibles(base_p)
        periodos_a_cargar = []
        
        print(f"Períodos cargados: {periodos_cargados}")
        
        # Verificar qué datos necesitan ser cargados
        if archivo_1_existe and "2025_01_06" not in periodos_cargados:
            periodos_a_cargar.append(("2025_01_06", archivo_202501_202506))
        
        if archivo_2_existe and "2025_07_12" not in periodos_cargados:
            periodos_a_cargar.append(("2025_07_12", archivo_202507_202512))
        
        # Cargar datos si es necesario
        if periodos_a_cargar:
            print(f"Cargando {len(periodos_a_cargar)} período(s) en SQLite...")
            for periodo, archivo in periodos_a_cargar:
                try:
                    print(f"  - Cargando período {periodo}...")
                    CJ.CargarDataBaseSQLite(archivo, base_p, nombre_tabla, periodo)
                    CJ.GuardarPeriodoCargado(base_p, periodo)
                    print(f"   Período {periodo} cargado exitosamente")
                except Exception as e:
                    print(f"  ✗ Error cargando período {periodo}: {str(e)}")
                    py.alert(f"Error al cargar datos de Cajas ({periodo}):\n{str(e)}")
                    return
        
        # Obtener períodos finales disponibles
        periodos_cargados = CJ.ObtenerPeriodosDisponibles(base_p)
        
        if not periodos_cargados:
            py.alert("ERROR: No hay datos cargados en la base de datos SQLite")
            return
        
        print(f"Iniciando búsqueda en períodos: {periodos_cargados}")
        
        # Ejecutar búsqueda en Cajas
        nomb_archivo_busqueda = ruta_base + r"\Base_Busqueda.xlsx"
        parametros = ["nom_aplpatpre", "nom_aplmatpre", "nom_pre", "nom_razpre"]
        
        # Procesar búsqueda usando función de Cajas.py (guardar reportes en carpeta_salida)
        CJ.procesobusuqeda(base_p, nomb_archivo_busqueda, nombre_tabla, parametros, carpeta_salida, periodos_cargados)
        
        py.alert(f"Búsqueda en Cajas completada.\nPeríodos: {', '.join(periodos_cargados)}\nReportes en: {carpeta_salida}")
        
    except Exception as e:
        print(f"Error en PBusquedaCajas: {str(e)}")
        py.alert(f"Error en búsqueda de Cajas:\n{str(e)}")

#==============================================================================

#==============================================================================
# Función auxiliar para validar porcentaje
#==============================================================================
def validar_porcentaje(porcentaje_str):
    """Convierte porcentaje a entero, maneja casos de cadena vacía o None"""
    if porcentaje_str == '' or porcentaje_str is None:
        return 0
    try:
        return int(porcentaje_str)
    except ValueError:
        return 0

#==============================================================================
#Leer Resultado
#Funcion que obtiene datos de la matriz de busqueda
#def LlenarResultados(Porcentaje_resultado,Base_Resultado,Fila_Resultado
#,Nombre_Base,Fila_Encontrado_Base,Columna_Busqueda,Base_Busuqeda,Columna_B
#==============================================================================
def LlenarResultados(porcentaje, resultadosB,fila,libro,filaE,colB1,valoresAux, colI,skiprows_applied=0):
    auxP=porcentaje
    b=fila
    a=colI
    row_offset=skiprows_applied+2
    #a=filab
    if auxP>=60:
        print('LlenarResultados_P_1_1' + '-->' + str(b))
        if validar_porcentaje(resultadosB.loc[b, 'Porcentaje'])<60:
            resultadosB.loc[b, 'Libro']=""
            resultadosB.loc[b, 'Hoja']=""
            resultadosB.loc[b, 'Fila']=""
            resultadosB.loc[b, 'Columna']=""
            resultadosB.loc[b, 'Valor']=""
        if resultadosB.loc[b, 'Libro']=="":
            resultadosB.loc[b, 'Libro']=libro
            resultadosB.loc[b, 'Hoja']=libro
            resultadosB.loc[b, 'Fila']=str(filaE+row_offset)
            resultadosB.loc[b, 'Columna']=str(a+1)
            resultadosB.loc[b, 'Valor']=valoresAux[colB1][filaE]
        else:
            # Concatenar y deduplicar valores
            fila_actual = str(filaE+row_offset)
            columna_actual = str(a+1)
            valor_actual = valoresAux[colB1][filaE]
            
            filas_list = resultadosB.loc[b, 'Fila'].split('|')
            columnas_list = resultadosB.loc[b, 'Columna'].split('|')
            valores_list = resultadosB.loc[b, 'Valor'].split('|')
            
            # Agregar solo si no existe duplicado
            if fila_actual not in filas_list:
                filas_list.append(fila_actual)
            if columna_actual not in columnas_list:
                columnas_list.append(columna_actual)
            if valor_actual not in valores_list:
                valores_list.append(valor_actual)
            
            resultadosB.loc[b, 'Libro']=resultadosB.loc[b, 'Libro'] + '|' + libro
            resultadosB.loc[b, 'Hoja']=resultadosB.loc[b, 'Hoja'] + '|' + libro
            resultadosB.loc[b, 'Fila']='|'.join(filas_list)
            resultadosB.loc[b, 'Columna']='|'.join(columnas_list)
            resultadosB.loc[b, 'Valor']='|'.join(valores_list)
        if auxP>validar_porcentaje(resultadosB.loc[b, 'Porcentaje']):
            resultadosB.loc[b, 'Porcentaje']=str(auxP)
    else:
        print('LlenarResultados_P_1_2'  + '-->' + str(b))
        if auxP>validar_porcentaje(resultadosB.loc[b, 'Porcentaje']):
            resultadosB.loc[b, 'Porcentaje']=str(auxP)
            if resultadosB.loc[b, 'Libro']=="":
                resultadosB.loc[b, 'Libro']=libro #fbasetB[0]
                resultadosB.loc[b, 'Hoja']=libro
                resultadosB.loc[b, 'Fila']=str(filaE)
                resultadosB.loc[b, 'Columna']=str(a+1)
                resultadosB.loc[b, 'Valor']= valoresAux[colB1][filaE]
            else:
                # Concatenar y deduplicar valores
                fila_actual = str(filaE)
                columna_actual = str(a+1)
                valor_actual = valoresAux[colB1][filaE]
                
                filas_list = resultadosB.loc[b, 'Fila'].split('|')
                columnas_list = resultadosB.loc[b, 'Columna'].split('|')
                valores_list = resultadosB.loc[b, 'Valor'].split('|')
                
                # Agregar solo si no existe duplicado
                if fila_actual not in filas_list:
                    filas_list.append(fila_actual)
                if columna_actual not in columnas_list:
                    columnas_list.append(columna_actual)
                if valor_actual not in valores_list:
                    valores_list.append(valor_actual)
                
                resultadosB.loc[b, 'Libro']=resultadosB.loc[b, 'Libro'] + '|' + libro
                resultadosB.loc[b, 'Hoja']=resultadosB.loc[b, 'Hoja'] + '|' + libro
                resultadosB.loc[b, 'Fila']='|'.join(filas_list)
                resultadosB.loc[b, 'Columna']='|'.join(columnas_list)
                resultadosB.loc[b, 'Valor']='|'.join(valores_list)
        else:
            pass
                                
#==============================================================================
#Leer Resultado
#Funcion que obtiene datos de la matriz de busqueda
#def LlenarResultados(Porcentaje_resultado,Base_Resultado,Fila_Resultado
#,Nombre_Base,Fila_Encontrado_Base,Columna_Busqueda,Base_Busuqeda,Columna_B
#==============================================================================
def LlenarResultados1(porcentaje, resultadosB,fila,libro,filaE,colB1,
                      valoresV, colI,idB,colB2,colB3,colND,skiprows_applied=0):
    auxP=porcentaje
    b=fila
    a=colI
    row_offset=skiprows_applied+2
    if auxP>=40:
        print('LlenarResultados1_P_1_1' + '-->'+str(fila))
        if validar_porcentaje(resultadosB.loc[b, 'Porcentaje'])<40:
            resultadosB.loc[b, 'Libro']=""
            resultadosB.loc[b, 'Hoja']=""
            resultadosB.loc[b, 'Fila']=""
            resultadosB.loc[b, 'Columna']=""
            resultadosB.loc[b, 'Valor']=""
        if resultadosB.loc[b, 'Libro']=="":
            resultadosB.loc[b, 'Libro']=libro
            resultadosB.loc[b, 'Hoja']=libro
            resultadosB.loc[b, 'Fila']=str(filaE+row_offset) #str(a+1)
            resultadosB.loc[b, 'Columna']=str(a+1)
            if idB==1:
                resultadosB.loc[b, 'Valor']=valoresV[colB1][filaE] 
            else:
                resultadosB.loc[b, 'Valor']=(valoresV[colB1][filaE] + ' ' + 
                                         valoresV[colB2][filaE] + ' ' +
                                         valoresV[colB3][filaE] )
            if colND!='':
                resultadosB.loc[b, 'Valor']=resultadosB.loc[b, 'Valor']+';'+valoresV[colND][filaE] 
        else:
            # Concatenar y deduplicar valores
            fila_actual = str(filaE+row_offset)
            columna_actual = str(a+1)
            
            if idB==1:
                valor_actual = valoresV[colB1][filaE]
            else:
                valor_actual = (valoresV[colB1][filaE] + ' ' + 
                               valoresV[colB2][filaE] + ' ' +
                               valoresV[colB3][filaE])
            if colND!='':
                valor_actual = valor_actual + ';' + valoresV[colND][filaE]
            
            filas_list = resultadosB.loc[b, 'Fila'].split('|')
            columnas_list = resultadosB.loc[b, 'Columna'].split('|')
            valores_list = resultadosB.loc[b, 'Valor'].split('|')
            
            # Agregar solo si no existe duplicado
            if fila_actual not in filas_list:
                filas_list.append(fila_actual)
            if columna_actual not in columnas_list:
                columnas_list.append(columna_actual)
            if valor_actual not in valores_list:
                valores_list.append(valor_actual)
            
            resultadosB.loc[b, 'Libro']=resultadosB.loc[b, 'Libro'] + '|' + libro
            resultadosB.loc[b, 'Hoja']=resultadosB.loc[b, 'Hoja'] + '|' + libro
            resultadosB.loc[b, 'Fila']='|'.join(filas_list)
            resultadosB.loc[b, 'Columna']='|'.join(columnas_list)
            resultadosB.loc[b, 'Valor']='|'.join(valores_list) 
        if auxP>validar_porcentaje(resultadosB.loc[b, 'Porcentaje']):
            resultadosB.loc[b, 'Porcentaje']=str(auxP)
    else:
        print('LlenarResultados1_P_1_2_2' + '_'+str(fila))
        if auxP>validar_porcentaje(resultadosB.loc[b, 'Porcentaje']):
            resultadosB.loc[b, 'Porcentaje']=str(auxP)
            if resultadosB.loc[b, 'Libro']=="":
                resultadosB.loc[b, 'Libro']=libro#fbasetB[0]
                resultadosB.loc[b, 'Hoja']=libro
                resultadosB.loc[b, 'Fila']=str(valoresV.index[0]+row_offset) #str(a+1)
                resultadosB.loc[b, 'Columna']=str(a+1)
                resultadosB.loc[b, 'Valor']= valoresV[colB1][filaE]
            else:
                resultadosB.loc[b, 'Libro']=resultadosB.loc[b, 'Libro'] + '|' + libro
                resultadosB.loc[b, 'Hoja']=resultadosB.loc[b, 'Hoja'] + '|' + libro
                resultadosB.loc[b, 'Fila']=resultadosB.loc[b, 'Fila'] + '|' + str(valoresV.index[0]+row_offset)
                resultadosB.loc[b, 'Columna']=resultadosB.loc[b, 'Columna'] + '|' + str(a+1)
                resultadosB.loc[b, 'Valor']= resultadosB.loc[b, 'Valor'] + '|' + valoresV[colB1][filaE]
            if colND!='':
                resultadosB.loc[b, 'Valor']=resultadosB.loc[b, 'Valor']+';'+valoresV[colND][filaE] 
        else:
            pass
                    
#==============================================================================
#Leer Resultado
#Funcion que obtiene datos de la matriz de busqueda
#==============================================================================
def LeerResultados(narchivo, nhoja):
    rutaOrig=varInicial [1][0]
    excel_of=pd.ExcelFile(rutaOrig +'\\' + narchivo) #Lee archivo excel
    hojaB=excel_of.parse(nhoja,usecols =[0,1,2,3,4,5,6,7,8,9,10],dtype =str)#Solo leer las columnas que existen (0-10)
    hojaB.fillna("", inplace = True)
    excel_of.close()
    return hojaB
#==============================================================================
#==============================================================================
#Proceso que crea variable de Area Registral
#==============================================================================
def MenuP():
    global root
    root = tk.Tk()  #tkinter.Tk()  
    root.title('Menú Principal')
    root.geometry("1000x400")
    root.resizable(True, True)
    
    # Configurar pesos de filas y columnas para que se adapten
    root.grid_rowconfigure(0, weight=1)
    root.grid_rowconfigure(1, weight=1)
    root.grid_columnconfigure(0, weight=1)
    root.grid_columnconfigure(1, weight=1)
    
    # FILA 0 (Superior)
    #Opcion 1 - Limpiar Base de Datos (Naranja - Arriba a la izquierda)
    botonNuevo5 = tk.Button(root, text="Limpiar Base de Datos" +'\n' + 
                            "SQLite" +'\n' + "(Cajas)",
                            fg="white", bg="#FF8C00", font=("Arial", 11, "bold"),
                            command=Close_Window_5, padx=25, pady=25)
    botonNuevo5.grid(row=0, column=0, padx=5, sticky="nsew", pady=5)

    #Opcion 2 - BASE 1 (Verde - Arriba a la derecha)
    botonNuevo2 = tk.Button(root, text="Iniciar Busqueda en :" +'\n' + 
                            "1_BANCOS_VEND_INMUEB" +'\n' + "_CREDHIP_2025.xlsx",
                            fg="white", bg="#228B22", font=("Arial", 11, "bold"),
                            command=Close_Window_2, padx=25, pady=25)
    botonNuevo2.grid(row=0, column=1, padx=5, sticky="nsew", pady=5)
    
    # FILA 1 (Inferior)
    #Opcion 3 - Convertir Data (Rojo - Abajo a la izquierda, ocupa toda la altura)
    botonNuevo1 = tk.Button(root, text="Convertir Data " +'\n' + "de Busqueda",
                            fg="white", bg="#8B0000", font=("Arial", 12, "bold"),
                            command=Close_Window_1, padx=25, pady=25)
    botonNuevo1.grid(row=1, column=0, padx=5, sticky="nsew", pady=5)

    #Opcion 4 - BASE 2 (Azul Oscuro - Centro-derecha abajo)
    botonNuevo3 = tk.Button(root, text="Iniciar Busqueda en :" +'\n' + 
                            "2_CAJAS_" +'\n' + "CREDDESEMBOLSADOS_2025.txt",
                            fg="white", bg="#00008B", font=("Arial", 11, "bold"),
                            command=Close_Window_3, padx=25, pady=25)
    botonNuevo3.grid(row=1, column=1, padx=5, sticky="nsew", pady=5)
    
    #Opcion 5 - BASE 3 (Azul Claro - Derecha abajo)
    botonNuevo4 = tk.Button(root, text="Iniciar Busqueda en :" +'\n' + 
                            "3_TBL_MUNI_PREDIOS" +'\n' + "_2025.txt",
                            fg="black", bg="#87CEEB", font=("Arial", 11, "bold"),
                            command=Close_Window_4, padx=25, pady=25)
    botonNuevo4.grid(row=2, column=1, padx=5, sticky="nsew", pady=5)

    
    root.mainloop()
#==============================================================================
#Procesos de Menú:
#Opciones del Menu Principal
#==============================================================================
def Close_Window_1 ():
    root.destroy()
    procesoP1()
    print("Proceso Finalizo con exito ==> se completo la columna de Busqueda")
    py.alert("Proceso Ejecutado con exito ",timeout=1600)
    MenuP()
#==============================================================================
#==============================================================================
def Close_Window_2 ():
    root.destroy()
    PBusquedaP(1)
    print("Proceso Finalizo con exito ==> se completo Busqueda")
    py.alert("Proceso Ejecutado con exito ",timeout=1600)
    MenuP()
#==============================================================================
#==============================================================================
def Close_Window_3 ():
    root.destroy()
    PBusquedaP(2)
    print("Proceso Finalizo con exito ==> se completo Busqueda")
    py.alert("Proceso Ejecutado con exito ",timeout=1600)
    MenuP()
#==============================================================================
#==============================================================================
def Close_Window_4 ():
    root.destroy()
    PBusquedaP(3)
    print("Proceso Finalizo con exito ==> se completo Busqueda")
    py.alert("Proceso Ejecutado con exito ",timeout=1600)
    MenuP()
#==============================================================================
#==============================================================================
def Close_Window_5 ():
    root.destroy()
    EliminarBaseDatos()
    MenuP()
#==============================================================================
#==============================================================================
# Procedimiento para ejecutar la funcion de completar columna de busuqeda
# 
#==============================================================================   
def procesoP1():
    #baseData=leerBaseDatos
    carpeta_salida = crear_carpeta_resultados()
    TP1.completar_NB1(1,varInicial[1][0],carpeta_salida)

        
#==============================================================================
#================================================================================
# Procedimiento para :
# 
#==============================================================================   
def busquedaPrincipal():
    #baseData=leerBaseDatos
    PBusquedaP()
        
#==============================================================================
#==============================================================================
# Funcion principal que llama a las diversas funciones para la ejecucion de los 
# procesos
#==============================================================================
def main():
     try:
         py.alert("Ejecutando ROBOT SSUNARP ",timeout=800)#Mensaje de incio de asignacion
         ParametrosInicio()
         MenuP()
         # busquedaPrincipal()
         print(varInicial)
         print("Finalizo con exito")
     except Exception as e:
         print("Se produjo un error")
         print(e)
         SystemExit()
         
if __name__ == "__main__":
    main()